package BLC

type GetBlocks struct {
	AddrFrom string//当前节点地址
}
