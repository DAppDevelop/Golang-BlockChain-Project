package BLC

type BlockData struct {
	AddrFrom string //当前节点地址
	Block []byte//区块序列化数据
}
